<template>
  <div class="blog">
      <div class="site-section bg-light">
      <div class="container">
        <div class="row mb-5">
          <div class="col-12 text-center" style="margin-top: 60px;">
            <h2 class="section-title mb-3 text-normal-blue">BLOGS</h2>
          </div>
        </div>
        <div class="container">
          <div class="row">
            <!-- <div class="row"> 
              <div class="col-xs-12 col-sm-3 col-md-3">
                  <a href="#">
                      <img src="http://wanderluxe.theluxenomad.com/wp-content/uploads/2014/10/http-www.urchinbali.comgallery.jpg" class="img-responsive img-box img-thumbnail"> 
                  </a>
              </div> 
              <div class="col-xs-12 col-sm-9 col-md-9">
                  <h4><a href="#">5 of Bali’s Spanking New Haunts - WanderLuxe Magazine</a></h4>
                  <p>Naturally, we know where Bali's newest restaurants are and what to order, so give that private chef a rest and check out these spanking new haunts.</p>
              </div> 
            </div> -->
            <ArticlesList :articles="articles"></ArticlesList>
          </div>
        </div>

        
      </div>
    </div>
    <Footer/>
  </div>
</template>

<script>
import ArticlesList from "../../components/BlogList.vue";
import gql from "graphql-tag";
import Footer from "@/components/Footer.vue";
export default {
  components: {
    ArticlesList,
    Footer
  },
  data() {
    return {
      articles: []
    };
  },
  apollo: {
    articles: gql`
      query Articles {
        articles {
          id
          title
          content
          image {
            url
          }
          category {
            name
          }
        }
      }
    `
  }
};
</script>

<!-- <template>
    <div class="blog">
     <div class="site-section bg-light">
      <div class="container">
        <div class="row mb-5">
          <div class="col-12 text-center" style="margin-top: 60px;">
            <h2 class="section-title mb-3 text-normal-blue">Blogs</h2>
          </div>
        </div>
            <div class="col-lg-8 entries">

            <article class="entry" data-aos="fade-up">

              <div class="entry-img">
                <img src="images/img_2.jpg" alt="" class="img-fluid">
              </div>

              <h2 class="entry-title">
                <a href="blog-single.html">Dolorum optio tempore voluptas dignissimos cumque fuga qui quibusdam quia reiciendis</a>
              </h2>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="icofont-user"></i> <a href="blog-single.html">John Doe</a></li>
                  <li class="d-flex align-items-center"><i class="icofont-wall-clock"></i> <a href="blog-single.html"><time datetime="2020-01-01">Jan 1, 2020</time></a></li>
                  <li class="d-flex align-items-center"><i class="icofont-comment"></i> <a href="blog-single.html">12 Comments</a></li>
                </ul>
              </div>

              <div class="entry-content">
                <p>
                  Et eveniet enim. Qui velit est ea dolorem doloremque deleniti aperiam unde soluta. Est cum et quod quos aut ut et sit sunt. Voluptate porro consequatur assumenda perferendis dolore.
                </p>
                <div class="read-more">
                  <a href="blog-single.html">Read More</a>
                </div>
              </div>

            </article>
          </div>
      </div>
     </div>
    </div>
</template> -->
