<template>
  <div>
    <div class="container" style="margin-top: 40px;">
      <div class="row">
      <div class="col-lg-7">
        <h1 class="text-normal-blue" style="font-size: 24px; margin: 20px; margin-left: 0px;">{{ article.title }}</h1>
        <div style="color: black;">
          <vue-markdown-it
            v-if="article.content"
            :source="article.content"
            id="editor"/>
          <p v-if="article.published_at" style="margin-top: 25px; color: brown;">
            {{ moment(article.published_at).format("MMM Do YY") }}
          </p>
        </div>
      </div>
      <div class="col-lg-5">
        <img style="margin: 20px;" width="650" v-if="article.image" :src="api_url + article.image.url"/>
      </div>
      
      </div>
    </div>
    <Footer/>
  </div>
</template>

<script>
var moment = require("moment");
import VueMarkdownIt from "vue-markdown-it";
import gql from "graphql-tag";
import Footer from "@/components/Footer.vue";

export default {
  data() {
    return {
      article: {},
      moment: moment,
      api_url:"http://localhost:1337",
      routeParam: this.$route.params.id
    };
  },
  components: {
    VueMarkdownIt,
    Footer
  },
  apollo: {
    article: {
      query: gql`
        query Articles($id: ID!) {
          article(id: $id) {
            id
            title
            content
            image {
              url
            }
            published_at
          }
        }
      `,
      variables() {
        return {
          id: this.routeParam
        };
      }
    }
  }
};
</script>
