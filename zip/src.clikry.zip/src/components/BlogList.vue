<template>
  <div>
      <div>
        <router-link
          v-for="article in articles"
          :to="{ path: '/blog/' + article.id }"
          class="uk-link-reset"
          :key="article.id"
        >
            <div class="row"> 
              <div class="col-xs-12 col-sm-3 col-md-3">
                  <a href="#">
                      <img :src="api_url + article.image.url" class="img-responsive img-box img-thumbnail"> 
                  </a>
              </div> 
              <div class="col-xs-12 col-sm-9 col-md-9">
                  <h3>{{ article.title }}</h3>
                  <p v-if="article.category">{{ article.category.name }}</p>
              </div> 
            </div><hr>
        </router-link>
      </div>
      <div>
         <!--  <router-link
            v-for="article in rightArticles"
            :to="{ path: '/blog/' + article.id }"
            class="uk-link-reset"
            :key="article.id"
          >
            <div class="row"> 
              <div class="col-xs-12 col-sm-3 col-md-3">
                  <a href="#">
                      <img :src="api_url + article.image.url" class="img-responsive img-box img-thumbnail"> 
                  </a>
              </div> 
              <div class="col-xs-12 col-sm-9 col-md-9">
                  <h4 v-if="article.category">{{ article.category.name }}</h4>
                  <p>{{ article.title }}</p>
              </div> 
            </div>
          </router-link> -->
      </div>
    </div>
</template>

<script>
export default {
  data: function() {
    return {
      api_url:"http://localhost:1337",
      state: process.env.NODE_ENV
    };
  },
  props: {
    articles: Array
  },
  computed: {
    leftArticlesCount() {
      return Math.ceil(this.articles.length / 5);
    },
    leftArticles() {
      return this.articles.slice(0, this.leftArticlesCount);
    },
    rightArticles() {
      return this.articles.slice(this.leftArticlesCount, this.articles.length);
    }
  }
};
</script>
