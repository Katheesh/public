<template>
  <div id="app">
    <div id="overlayer"></div>
    <div class="loader">
      <div class="spinner-border text-primary" role="status">
        <span class="sr-only">Loading...</span>
      </div>
    </div>

    <section id="topbar" class="d-none d-lg-block">
      <div class="container d-flex">
        <div class="contact-info mr-auto">
          <i class="icofont-envelope"></i
          ><a href="mailto:contact@clikry.com">contact@clikry.com</a>
          <i class="icofont-phone"></i> +1 972 836 9241
        </div>
        <div class="social-links">
          <a href="#" class="twitter"><i class="icon-twitter"></i></a>
          <a href="#" class="facebook"><i class="icon-facebook"></i></a>
          <a href="#" class="instagram"><i class="icon-instagram"></i></a>
          <a href="#" class="linkedin"><i class="icon-linkedin"></i></a>
          <a href="/blogs" class="">BLOG</a>
          <a href="http://localhost:1337/admin" target="_blank" class="">LOGIN</a>
        </div>
      </div>
    </section>
    
    <div class="container" id="home-section">
      <header class="header_area">
      <div class="main_menu">
        <nav class="navbar navbar-expand-lg navbar-light" id="navbar">
          <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <a href="/" class="mb-0"><img src="images/logo.png"/></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
             aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="icon-menu"></span>
            </button>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse offset" id="navbarSupportedContent">
              <ul class="nav navbar-nav menu_nav justify-content-center">
                <li class="nav-item"><router-link to="/"><a class="nav-link">Home</a></router-link></li>
                <li class="nav-item"><router-link to="/about"><a class="nav-link">About</a></router-link></li>
                <li class="nav-item submenu dropdown">
                  <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                   aria-expanded="false">Business Services</a>
                  <ul class="dropdown-menu">
                    <li class="nav-item"><router-link to="/mergers-and-acquisition"><a class="nav-link">Mergers and Acquisition</a></router-link></li>
                    <li class="nav-item"><router-link to="/advisory-consulting"><a class="nav-link">Advisory Consulting</a></router-link></li>
                  </ul>
                </li>
                <li class="nav-item"><router-link to="/contact"><a class="nav-link">Contact</a></router-link></li>
              </ul>
            </div>
          </div>
        </nav>
      </div>
    </header>
      <transition name="fade" mode="out-in">
        <router-view />
      </transition>
    </div>
  </div>
</template>

<style>

.router-link-active {
  color: #1573a2;
}

.fade-enter {
  opacity: 0;
}

.fade-enter-active {
  transition: opacity 2s ease;
}

.fade-leave {
}

.fade-leave-active {
  transition: opacity 2s ease;
  opacity: 0;
}

#topbar {
  background: #f8f6f5;
  padding: 10px 0;
  font-size: 14px;
}

#topbar .contact-info a {
  line-height: 1;
  color: #4d4643;
  transition: 0.3s;
}

#topbar .contact-info a:hover {
  color: #1573a2;
}

#topbar .contact-info i {
  color: #1573a2;
  padding: 4px;
}

#topbar .contact-info .icofont-phone {
  padding-left: 20px;
  margin-left: 20px;
  border-left: 1px solid #e9e9e9;
}

#topbar .social-links a {
  color: #836a61;
  padding: 4px 0 4px 20px;
  display: inline-block;
  line-height: 1px;
  transition: 0.3s;
}

#topbar .social-links a:hover {
  color: #1573a2;
}

</style>

<script>

  export default {
    components: {

    },
    created () {
      window.addEventListener('scroll', this.handleScroll);
    },
    destroyed () {
      window.removeEventListener('scroll', this.handleScroll);
    },
    methods: {
      handleScroll () {
        let header = document.querySelector(".header_area");
        if (window.scrollY > 50) {
        header.classList.add('navbar_fixed'); 
        } else if (window.scrollY < 50) {
          header.classList.remove('navbar_fixed');
        }
      }
    }
  }
</script>

<!-- 
A173X0022478234
<div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>
      <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner" >
        <div class="container">
          <div class="row align-items-center">
            <div class="col-6 col-md-3 col-xl-2  d-block">
              <a href="/" class="mb-0"><img src="images/logo.png"/></a>
            </div>
            <div class="col-12 col-md-9 col-xl-10 main-menu">
              <nav
                class="site-navigation position-relative text-right"
                role="navigation"
              >
                <ul
                  class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block ml-0 pl-0"
                >
                  <li>
                    <router-link class="nav-link" to="/">HOME</router-link>
                  </li>
                  <li class="has-children">
                    <a href="javascript:void(0)" class="nav-link">SERVICES</a
                    >
                    <ul class="dropdown arrow-top">
                      <li class="has-children">
                        <a href="javascript:void(0)">Business Services</a>
                        <ul class="dropdown">
                          <li>
                            <router-link
                              to="/mergers-and-acquisition"
                              class="nav-link"
                              >Mergers and Acquisition</router-link
                            >
                          </li>
                          <li>
                            <router-link
                              to="/advisory-consulting"
                              class="nav-link"
                              >Advisory Consulting</router-link
                            >
                          </li>
                        </ul>
                      </li>
                      <li class="has-children">
                        <a href="javascript:void(0)">Technology Services</a>
                        <ul class="dropdown">
                          <li><a href="#">Storage as Services</a></li>
                          <li>
                            <a href="#"
                              >Disaster Recovery and data Protection
                            </a>
                          </li>
                          <li>
                            <a href="#">Business Application Maintenance</a>
                          </li>
                        </ul>
                      </li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="javascript:void(0)" class="nav-link">SOLUTIONS</a>
                    <ul class="dropdown arrow-top">
                      <li class="has-children">
                        <a href="#">Cloud and Big data</a>
                        <ul class="dropdown">
                          <li><a href="#">Multi-Cloud Data Migration </a></li>
                          <li>
                            <a href="#">Data Transformation and Engineering</a>
                          </li>
                          <li><a href="#">Cloud Architecture & Design</a></li>
                        </ul>
                      </li>
                      <li class="has-children">
                        <a href="#">Digital Platform</a>
                        <ul class="dropdown">
                          <li>
                            <a href="#" @click="handleClick"
                              >Customer Experience</a
                            >
                          </li>
                          <li><a href="#">Real time Analytics</a></li>
                          <li><a href="#">Omnichannel Ecommerce </a></li>
                        </ul>
                      </li>
                    </ul>
                  </li>
                  <li>
                    <router-link class="nav-link" to="/about"
                      >ABOUT US
                    </router-link>
                  </li>
                  <li>
                    <router-link class="nav-link" to="/contact"
                      >CONTACT</router-link
                    >
                  </li>
                </ul>
              </nav>

            </div>
            <div class="col-6 col-md-9 d-inline-block d-lg-none ml-md-0">
              <a
                href="#"
                class="site-menu-toggle js-menu-toggle text-black float-right"
                ><span class="icon-menu h3"></span
              ></a>
            </div>
          </div>
        </div>
      </header> -->