
export default {
    user_service_url: 'http://localhost:8090/api/v1',
};