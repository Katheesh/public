<template>
    <div class="login">
        <div class="column is-4 is-offset-4">
            <h1 class="title has-text-centered">Login</h1>
            <LoginForm name="login"/>
            <br>
            <center>
                <v-facebook-login app-id="638024323562577"></v-facebook-login>
            </center>
            
        </div>
    </div>
</template>

<script>
    import LoginForm from '@/components/LoginForm.vue';

    import VFacebookLogin from 'vue-facebook-login-component';

    export default {
        name: 'Login',
        components: {
            LoginForm,
            VFacebookLogin
        }
    };
</script>
