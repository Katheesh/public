export const DELETE_LAYOUT = 'ContentManager/Main/DELETE_LAYOUT';
export const DELETE_LAYOUTS = 'ContentManager/Main/DELETE_LAYOUTS';
export const GET_DATA_SUCCEEDED = 'ContentManager/Main/GET_DATA_SUCCEEDED';
export const GET_LAYOUT_SUCCEEDED = 'ContentManager/Main/GET_LAYOUT_SUCCEEDED';
export const ON_CHANGE_LIST_LABELS = 'ContentManager/Main/ON_CHANGE_LIST_LABELS';
export const RESET_LIST_LABELS = 'ContentManager/Main/RESET_LIST_LABELS';
export const RESET_PROPS = 'ContentManager/Main/RESET_PROPS';
