import React from 'react';

const Ul = () => {
  return (
    <svg width="13" height="7" xmlns="http://www.w3.org/2000/svg">
      <g fill="none" fillRule="evenodd">
        <path fill="#333740" d="M5 0h8v1H5zM5 2h8v1H5zM5 4h8v1H5zM5 6h8v1H5z" />
        <rect stroke="#333740" x=".5" y=".5" width="2" height="2" rx="1" />
        <rect stroke="#333740" x=".5" y="4.5" width="2" height="2" rx="1" />
      </g>
    </svg>
  );
};

export default Ul;
