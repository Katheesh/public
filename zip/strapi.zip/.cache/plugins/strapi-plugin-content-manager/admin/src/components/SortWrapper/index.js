import styled from 'styled-components';

const SortWrapper = styled.div`
  .btn-group button {
    line-height: 28px;
  }
`;

export default SortWrapper;
