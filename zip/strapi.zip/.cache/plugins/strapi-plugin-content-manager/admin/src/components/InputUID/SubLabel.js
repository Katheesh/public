import styled from 'styled-components';

const SubLabel = styled.p`
  padding-top: 10px;
  line-height: normal;
  font-size: 1.3rem;
`;

export default SubLabel;
