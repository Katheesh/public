import styled from 'styled-components';

const ComponentInfosWrapper = styled.span`
  color: #9ea7b8;
  font-size: 13px;
  font-weight: 500;
`;

export default ComponentInfosWrapper;
