import { createContext } from 'react';

const ListViewContext = createContext();

export default ListViewContext;
